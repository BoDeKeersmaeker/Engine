#include "MiniginPCH.h"
#include "Observer.h"