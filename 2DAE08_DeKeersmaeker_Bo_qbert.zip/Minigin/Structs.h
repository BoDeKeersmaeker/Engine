#pragma once
namespace engine
{
	struct Color
	{
		float R{ 255.f };
		float G{ 255.f };
		float B{ 255.f };
	};

	struct Float2
	{
		float x{ 0 };
		float y{ 0 };
	};
}