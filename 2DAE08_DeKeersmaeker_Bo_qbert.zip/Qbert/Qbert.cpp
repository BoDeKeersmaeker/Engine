#include "Game.h"

int main(int, char* [])
{
    Game game;
    game.Run();
    return 0;
}