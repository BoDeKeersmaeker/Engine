#pragma once

enum class Direction
{
	TOPLEFT = 0,
	TOPRIGHT = 1,
	BOTTOMRIGHT = 2,
	BOTTOMLEFT = 3,
	LEFT = 4,
	RIGHT = 5
};

enum class GameMode
{
	Single,
	Coop,
	Versus
};